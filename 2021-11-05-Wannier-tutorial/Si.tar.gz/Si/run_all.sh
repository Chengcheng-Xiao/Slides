# Script needed:
# - https://github.com/Chengcheng-Xiao/Tools/blob/master/VASP/pp_gen.py
# - https://github.com/QijingZheng/pyband
cd 1-SCF
pp_gen.py -c POSCAR -xc PBE
echo "*-----------------------------------------------------*"
echo " Running SCF..."
echo "*-----------------------------------------------------*"
mpirun -n 4 vasp_std
cp CHGCAR ../2-BAND
cd ../2-BAND
pp_gen.py -c POSCAR -xc PBE
echo "*-----------------------------------------------------*"
echo " Running BAND..."
echo "*-----------------------------------------------------*"
mpirun -n 4 vasp_std
echo "*-----------------------------------------------------*"
echo " Plotting BAND..."
echo "*-----------------------------------------------------*"
pyband -y -7.5 20 -z 0 --occ '1-2' --spd 's p' -k "LGXKG"
cd ../1-SCF
cp CHGCAR WAVECAR ../3-WAN-FULL
cp CHGCAR WAVECAR ../3-WAN-VAL
cd ../3-WAN-FULL
pp_gen.py -c POSCAR -xc PBE
echo "*-----------------------------------------------------*"
echo " Generating Wannier input for all sp3 orbitals (8 bands)"
echo "*-----------------------------------------------------*"
mpirun -n 4 vasp_std
echo "*-----------------------------------------------------*"
echo " Running Wannier90.x"
echo "*-----------------------------------------------------*"
wannier90.x wannier90
cd ../3-WAN-VAL
pp_gen.py -c POSCAR -xc PBE
echo "*-----------------------------------------------------*"
echo " Generating Wannier input for valence bands (4 bands)"
echo "*-----------------------------------------------------*"
mpirun -n 4 vasp_std
echo "*-----------------------------------------------------*"
echo " Running Wannier90.x"
echo "*-----------------------------------------------------*"
wannier90.x wannier90
cd ../
echo " done. "
